package com.example.client2.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "configurations.external.services")
public class ExternalServicesConfig {
    private String inventoryService;
    private String shippingService;
    private String authService;

    public String getInventoryService() {
        return inventoryService;
    }

    public void setInventoryService(String inventoryService) {
        this.inventoryService = inventoryService;
    }

    public String getShippingService() {
        return shippingService;
    }

    public void setShippingService(String shippingService) {
        this.shippingService = shippingService;
    }

    public String getAuthService() {
        return authService;
    }

    public void setAuthService(String authService) {
        this.authService = authService;
    }
}