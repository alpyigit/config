package com.example.client2.controller;

import com.example.client2.config.AppConfig;
import com.example.client2.config.DatabaseConfig;
import com.example.client2.config.FeatureConfig;
import com.example.client2.config.ExternalServicesConfig;
import com.example.client2.config.SecurityConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ConfigController {

    @Autowired
    private AppConfig appConfig;

    @Autowired
    private DatabaseConfig databaseConfig;

    @Autowired
    private FeatureConfig featureConfig;

    @Autowired
    private ExternalServicesConfig externalServicesConfig;

    @Autowired
    private SecurityConfig securityConfig;

    @GetMapping("/config")
    public Map<String, Object> getConfig() {
        return Map.of(
            "appName", appConfig.getCfg_a066aa4a(),
            "appVersion", appConfig.getCfg_9d4ee38e(),
            "appDescription", appConfig.getCfg_8b9aa0a2(),
            "databaseUrl", databaseConfig.getCfg_04c13529(),
            "securityEnabled", featureConfig.isEnableSecurity(),
            "inventoryService", externalServicesConfig.getInventoryService(),
            "jwtSecret", securityConfig.getCfg_93e4b831()
        );
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "UP", "app", appConfig.getCfg_a066aa4a());
    }
}