package com.example.client2.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "configurations.database")
public class DatabaseConfig {
    private String cfg_04c13529;
    private String cfg_1182356a;
    private String cfg_1558f8e7;
    private String cfg_1992d8d6;

    public String getCfg_04c13529() {
        return cfg_04c13529;
    }

    public void setCfg_04c13529(String cfg_04c13529) {
        this.cfg_04c13529 = cfg_04c13529;
    }

    public String getCfg_1182356a() {
        return cfg_1182356a;
    }

    public void setCfg_1182356a(String cfg_1182356a) {
        this.cfg_1182356a = cfg_1182356a;
    }

    public String getCfg_1558f8e7() {
        return cfg_1558f8e7;
    }

    public void setCfg_1558f8e7(String cfg_1558f8e7) {
        this.cfg_1558f8e7 = cfg_1558f8e7;
    }

    public String getCfg_1992d8d6() {
        return cfg_1992d8d6;
    }

    public void setCfg_1992d8d6(String cfg_1992d8d6) {
        this.cfg_1992d8d6 = cfg_1992d8d6;
    }
}