package com.example.client2.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "configurations.security.jwt")
public class SecurityConfig {
    private String cfg_93e4b831;
    private int cfg_462a431b;

    public String getCfg_93e4b831() {
        return cfg_93e4b831;
    }

    public void setCfg_93e4b831(String cfg_93e4b831) {
        this.cfg_93e4b831 = cfg_93e4b831;
    }

    public int getCfg_462a431b() {
        return cfg_462a431b;
    }

    public void setCfg_462a431b(int cfg_462a431b) {
        this.cfg_462a431b = cfg_462a431b;
    }
}

@Component
@ConfigurationProperties(prefix = "configurations.cache.redis")
class CacheConfig {
    private String cfg_996eca95;
    private int cfg_c78cc564;
    private int cfg_dd399f02;

    public String getCfg_996eca95() {
        return cfg_996eca95;
    }

    public void setCfg_996eca95(String cfg_996eca95) {
        this.cfg_996eca95 = cfg_996eca95;
    }

    public int getCfg_c78cc564() {
        return cfg_c78cc564;
    }

    public void setCfg_c78cc564(int cfg_c78cc564) {
        this.cfg_c78cc564 = cfg_c78cc564;
    }

    public int getCfg_dd399f02() {
        return cfg_dd399f02;
    }

    public void setCfg_dd399f02(int cfg_dd399f02) {
        this.cfg_dd399f02 = cfg_dd399f02;
    }
}