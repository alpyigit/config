#!/usr/bin/env python3
"""
Config Obfuscator Main Script

This script orchestrates the entire configuration obfuscation process:
1. Obfuscates keys in YAML configuration files
2. Updates client applications to use obfuscated keys
"""

import os
import subprocess
import sys


def run_obfuscator():
    """Run the configuration obfuscator tool."""
    print("Step 1: Obfuscating configuration keys...")
    try:
        result = subprocess.run([
            sys.executable, 
            os.path.join(os.path.dirname(__file__), "config_obfuscator.py")
        ], check=True, capture_output=True, text=True)
        print(result.stdout)
        if result.stderr:
            print("STDERR:", result.stderr)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error running obfuscator: {e}")
        print("STDOUT:", e.stdout)
        print("STDERR:", e.stderr)
        return False


def run_refactor():
    """Run the configuration refactoring tool."""
    print("Step 2: Refactoring client applications...")
    try:
        result = subprocess.run([
            sys.executable, 
            os.path.join(os.path.dirname(__file__), "config_refactor.py")
        ], check=True, capture_output=True, text=True)
        print(result.stdout)
        if result.stderr:
            print("STDERR:", result.stderr)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error running refactor tool: {e}")
        print("STDOUT:", e.stdout)
        print("STDERR:", e.stderr)
        return False


def create_requirements_file():
    """Create a requirements file for the Python scripts."""
    requirements_content = """PyYAML>=5.4.1
"""
    with open(os.path.join(os.path.dirname(__file__), "requirements.txt"), "w") as f:
        f.write(requirements_content)
    print("Created requirements.txt")


def create_readme():
    """Create a README file explaining how to use the obfuscator."""
    readme_content = """# Config Obfuscator

This tool obfuscates configuration keys in YAML files and updates client applications to use the obfuscated keys.

## Prerequisites

- Python 3.6 or higher
- PyYAML library

## Installation

1. Install the required Python packages:
   ```
   pip install -r requirements.txt
   ```

## Usage

Run the main obfuscation script:
```
python config_obfuscator_main.py
```

This will:
1. Obfuscate all configuration keys in the `config-repo` directory
2. Generate a mapping file (`config-key-mapping.yaml`) with original-to-obfuscated key mappings
3. Update all client applications to use the obfuscated keys

## How It Works

1. **Obfuscation**: The `config_obfuscator.py` script reads all YAML files in the `config-repo` directory and obfuscates keys under the `configurations:` section.

2. **Mapping**: A mapping file is created that maps original keys to their obfuscated versions.

3. **Refactoring**: The `config_refactor.py` script updates Java ConfigurationProperties classes and controllers to use the obfuscated field names.

## Example

Original YAML:
```yaml
configurations:
  app:
    name: "My Application"
    version: "1.0.0"
```

Obfuscated YAML:
```yaml
configurations:
  cfg_a1b2c3d4:  # obfuscated 'app'
    cfg_e5f6g7h8: "My Application"  # obfuscated 'name'
    cfg_i9j0k1l2: "1.0.0"  # obfuscated 'version'
```

The corresponding Java classes are updated to use the obfuscated field names.
"""
    with open(os.path.join(os.path.dirname(__file__), "CONFIG_OBFUSCATOR_README.md"), "w") as f:
        f.write(readme_content)
    print("Created CONFIG_OBFUSCATOR_README.md")


def main():
    """Main function to run the complete obfuscation process."""
    print("Config Obfuscator")
    print("=" * 50)
    
    # Create supporting files
    create_requirements_file()
    create_readme()
    
    # Run the obfuscation process
    print("\nStarting configuration obfuscation process...\n")
    
    if not run_obfuscator():
        print("Obfuscation failed. Exiting.")
        return 1
    
    print()
    
    if not run_refactor():
        print("Refactoring failed. Exiting.")
        return 1
    
    print("\n" + "=" * 50)
    print("Configuration obfuscation completed successfully!")
    print("See CONFIG_OBFUSCATOR_README.md for usage instructions.")
    return 0


if __name__ == "__main__":
    sys.exit(main())