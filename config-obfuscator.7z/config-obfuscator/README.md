# Spring Boot Config Server ve Client Uygulamaları

Bu proje, bir Spring Boot Config Server ve 4 ayrı Config Client uygulamasından oluşmaktadır.

## Proje Yapısı

```
config-obfuscator/
├── config-server/           # Spring Cloud Config Server
├── config-repo/             # Konfigürasyon dosyaları (YAML)
│   ├── client-app-1.yml
│   ├── client-app-2.yml
│   ├── client-app-3.yml
│   └── client-app-4.yml
├── client-app-1/            # İlk Client Uygulaması
├── client-app-2/            # İkinci Client Uygulaması
├── client-app-3/            # Üçüncü Client Uygulaması
└── client-app-4/            # Dördüncü Client Uygulaması
```

## Özellikler

### Config Server
- **Port**: 8887
- **Profil**: native (dosya sistemi tabanlı)
- **Konfigürasyon Yolu**: `./config-repo`
- Spring Cloud Config Server kullanılarak yapılandırılmıştır

### Config Clients

#### Client App 1
- **Port**: 8081
- **Veritabanı**: H2 (In-Memory)
- **Özellikler**: Caching, Metrics, Payment Service entegrasyonu

#### Client App 2
- **Port**: 8082
- **Veritabanı**: PostgreSQL
- **Özellikler**: Security, Analytics, Redis Cache, JWT Authentication

#### Client App 3
- **Port**: 8083
- **Veritabanı**: MySQL
- **Özellikler**: OAuth2, Monitoring, Batch Processing, Advanced Analytics

#### Client App 4
- **Port**: 8084
- **Özellikler**: Konfigürasyon değerlerini constructor'da alma ve konsola yazdırma

## Kurulum ve Çalıştırma

### Ön Koşullar
- Java 17+
- Maven 3.6+

### 1. Config Server'ı Başlatma

```bash
cd config-server
mvn spring-boot:run
```

Config Server http://localhost:8887 adresinde çalışacaktır.

### 2. Client Uygulamaları Başlatma

Her client uygulamasını ayrı terminal penceresinde çalıştırın:

**Client App 1:**
```bash
cd client-app-1
mvn spring-boot:run
```

**Client App 2:**
```bash
cd client-app-2
mvn spring-boot:run
```

**Client App 3:**
```bash
cd client-app-3
mvn spring-boot:run
```

**Client App 4:**
```bash
cd client-app-4
mvn spring-boot:run
```

## Test Etme

### Config Server Test
Config Server'ın çalıştığını doğrulamak için:

```bash
# Client App 1 konfigürasyonunu almak
curl http://localhost:8887/client-app-1/default

# Client App 2 konfigürasyonunu almak
curl http://localhost:8887/client-app-2/default

# Client App 3 konfigürasyonunu almak
curl http://localhost:8887/client-app-3/default

# Client App 4 konfigürasyonunu almak
curl http://localhost:8887/client-app-4/default
```

### Client Uygulamaları Test

**Client App 1:**
```bash
curl http://localhost:8081/config
curl http://localhost:8081/health
```

**Client App 2:**
```bash
curl http://localhost:8082/config
curl http://localhost:8082/health
```

**Client App 3:**
```bash
curl http://localhost:8083/config
curl http://localhost:8083/health
```

**Client App 4:**
Uygulama başlatıldığında konfigürasyon değerlerini konsola yazdırır.

## Konfigürasyon Dosyaları

Her client uygulaması için `config-repo` dizininde ayrı YAML dosyaları bulunmaktadır:

- `client-app-1.yml`: Temel uygulama konfigürasyonu
- `client-app-2.yml`: Güvenlik ve cache özellikleri
- `client-app-3.yml`: Gelişmiş monitoring ve batch processing
- `client-app-4.yml`: Basit konfigürasyon örneği

## Actuator Endpoints

Tüm client uygulamalarda Spring Boot Actuator etkinleştirilmiştir:

- `/actuator/health` - Sağlık kontrolü
- `/actuator/info` - Uygulama bilgileri
- `/actuator/env` - Çevre değişkenleri
- `/actuator/configprops` - Konfigürasyon özellikleri

## Notlar

- Config Server başlatılmadan önce client uygulamalarını başlatmayın
- Konfigürasyon değişiklikleri için config-repo dizinindeki YAML dosyalarını düzenleyin
- Client uygulamaları otomatik olarak config server'dan konfigürasyonlarını alır
- Her client uygulaması farklı port ve veritabanı yapılandırması kullanır