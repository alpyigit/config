package com.example.client3.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "configurations.security.oauth2")
public class SecurityConfig {
    private String cfg_bcc75489;
    private String cfg_8005031b;
    private String cfg_bb152c58;

    public String getCfg_bcc75489() {
        return cfg_bcc75489;
    }

    public void setCfg_bcc75489(String cfg_bcc75489) {
        this.cfg_bcc75489 = cfg_bcc75489;
    }

    public String getCfg_8005031b() {
        return cfg_8005031b;
    }

    public void setCfg_8005031b(String cfg_8005031b) {
        this.cfg_8005031b = cfg_8005031b;
    }

    public String getCfg_bb152c58() {
        return cfg_bb152c58;
    }

    public void setCfg_bb152c58(String cfg_bb152c58) {
        this.cfg_bb152c58 = cfg_bb152c58;
    }
}

@Component
@ConfigurationProperties(prefix = "configurations.monitoring.metrics")
class MonitoringConfig {
    private boolean cfg_2226978b;
    private String cfg_cae38606;

    public boolean isCfg_2226978b() {
        return cfg_2226978b;
    }

    public void setCfg_2226978b(boolean cfg_2226978b) {
        this.cfg_2226978b = cfg_2226978b;
    }

    public String getCfg_cae38606() {
        return cfg_cae38606;
    }

    public void setCfg_cae38606(String cfg_cae38606) {
        this.cfg_cae38606 = cfg_cae38606;
    }
}

@Component
@ConfigurationProperties(prefix = "configurations.batch.job")
class BatchConfig {
    private int cfg_f9677cae;
    private int cfg_f77abcb2;

    public int getCfg_f9677cae() {
        return cfg_f9677cae;
    }

    public void setCfg_f9677cae(int cfg_f9677cae) {
        this.cfg_f9677cae = cfg_f9677cae;
    }

    public int getCfg_f77abcb2() {
        return cfg_f77abcb2;
    }

    public void setCfg_f77abcb2(int cfg_f77abcb2) {
        this.cfg_f77abcb2 = cfg_f77abcb2;
    }
}