package com.example.client3.controller;

import com.example.client3.config.AppConfig;
import com.example.client3.config.DatabaseConfig;
import com.example.client3.config.FeatureConfig;
import com.example.client3.config.ExternalServicesConfig;
import com.example.client3.config.SecurityConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ConfigController {

    @Autowired
    private AppConfig appConfig;

    @Autowired
    private DatabaseConfig databaseConfig;

    @Autowired
    private FeatureConfig featureConfig;

    @Autowired
    private ExternalServicesConfig externalServicesConfig;

    @Autowired
    private SecurityConfig securityConfig;

    @GetMapping("/config")
    public Map<String, Object> getConfig() {
        return Map.of(
            "appName", appConfig.getCfg_a066aa4a(),
            "appVersion", appConfig.getCfg_9d4ee38e(),
            "appDescription", appConfig.getCfg_8b9aa0a2(),
            "databaseUrl", databaseConfig.getCfg_04c13529(),
            "monitoringEnabled", featureConfig.isEnableMonitoring(),
            "analyticsService", externalServicesConfig.getAnalyticsService(),
            "oauth2ClientId", securityConfig.getCfg_bcc75489()
        );
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "UP", "app", appConfig.getCfg_a066aa4a());
    }
}