package com.example.client3.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "configurations.external.services")
public class ExternalServicesConfig {
    private String analyticsService;
    private String monitoringService;
    private String backupService;

    public String getAnalyticsService() {
        return analyticsService;
    }

    public void setAnalyticsService(String analyticsService) {
        this.analyticsService = analyticsService;
    }

    public String getMonitoringService() {
        return monitoringService;
    }

    public void setMonitoringService(String monitoringService) {
        this.monitoringService = monitoringService;
    }

    public String getBackupService() {
        return backupService;
    }

    public void setBackupService(String backupService) {
        this.backupService = backupService;
    }
}