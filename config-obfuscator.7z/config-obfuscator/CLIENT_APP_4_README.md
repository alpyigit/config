# Client App 4

This is the fourth client application in the config-obfuscator project. It demonstrates how to:

1. Create a new Spring Boot client application that connects to the Config Server
2. Define configuration properties using `@ConfigurationProperties`
3. Access configuration values in a service class constructor
4. Print configuration values to the console using `System.out.println`

## Structure

- `src/main/java/com/example/client4/` - Main application package
- `src/main/java/com/example/client4/config/AppConfig.java` - Configuration properties class
- `src/main/java/com/example/client4/service/ConfigDisplayService.java` - Service that prints config values
- `src/main/resources/application.yml` - Application configuration
- `config-repo/client-app-4/` - Configuration repository for this client
- `config-repo/client-app-4/client-app-4-runtime.yml` - Runtime configuration file

## Configuration

The application fetches its configuration from the Config Server at `http://localhost:8889`. The configuration includes:

- Application name
- Version
- Description

These values are printed to the console when the application starts.

## Running the Application

To run the application:

```bash
cd client-app-4
mvn spring-boot:run
```

When the application starts, it will automatically fetch configuration from the Config Server and display the values in the console.