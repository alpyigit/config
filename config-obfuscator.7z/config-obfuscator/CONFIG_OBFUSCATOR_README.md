# Config Obfuscator

This tool obfuscates configuration keys in YAML files and updates client applications to use the obfuscated keys.

## Prerequisites

- Python 3.6 or higher
- PyYAML library

## Installation

1. Install the required Python packages:
   ```
   pip install -r requirements.txt
   ```

## Usage

Run the main obfuscation script:
```
python config_obfuscator_main.py
```

This will:
1. Obfuscate all configuration keys in the `config-repo` directory
2. Generate a mapping file (`config-key-mapping.yaml`) with original-to-obfuscated key mappings
3. Update all client applications to use the obfuscated keys

## How It Works

1. **Obfuscation**: The `config_obfuscator.py` script reads all YAML files in the `config-repo` directory and obfuscates keys under the `configurations:` section.

2. **Mapping**: A mapping file is created that maps original keys to their obfuscated versions.

3. **Refactoring**: The `config_refactor.py` script updates Java ConfigurationProperties classes and controllers to use the obfuscated field names.

## Example

Original YAML:
```yaml
configurations:
  app:
    name: "My Application"
    version: "1.0.0"
```

Obfuscated YAML:
```yaml
configurations:
  cfg_a1b2c3d4:  # obfuscated 'app'
    cfg_e5f6g7h8: "My Application"  # obfuscated 'name'
    cfg_i9j0k1l2: "1.0.0"  # obfuscated 'version'
```

The corresponding Java classes are updated to use the obfuscated field names.
