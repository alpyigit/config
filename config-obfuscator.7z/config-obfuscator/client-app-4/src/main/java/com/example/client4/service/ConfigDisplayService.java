package com.example.client4.service;

import com.example.client4.config.AppConfig;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConfigDisplayService {

    private final AppConfig appConfig;

    @Autowired
    public ConfigDisplayService(AppConfig appConfig) {
        this.appConfig = appConfig;
    }

    @PostConstruct
    public void displayConfig() {
        System.out.println("===== Client App 4 Configuration =====");
        System.out.println("App Config: " + appConfig.toString());
        System.out.println("Name: " + appConfig.getCfg_b068931c());
        System.out.println("Version: " + appConfig.getCfg_2af72f10());
        System.out.println("Description: " + appConfig.getCfg_67daf92c());
        System.out.println("=====================================");
    }
}