package com.example.client4;

import com.example.client4.config.AppConfig;
import org.springframework.stereotype.Service;

@Service
public class TestUnobfuscatedCalls {
    
    private final AppConfig appConfig;
    
    public TestUnobfuscatedCalls(AppConfig appConfig) {
        this.appConfig = appConfig;
    }
    
    public void testMethodCalls() {
        // These method calls should be updated by the refactoring tool
        String name = appConfig.getCfg_b068931c();
        String version = appConfig.getCfg_2af72f10();
        String description = appConfig.getCfg_67daf92c();
        
        // Print the values
        System.out.println("Name: " + name);
        System.out.println("Version: " + version);
        System.out.println("Description: " + description);
        
        // Test setter calls as well
        appConfig.setCfg_b068931c("New Name");
        appConfig.setCfg_2af72f10("2.0.0");
        appConfig.setCfg_67daf92c("New Description");
    }
}