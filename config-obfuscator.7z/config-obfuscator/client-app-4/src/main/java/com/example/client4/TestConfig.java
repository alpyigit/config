package com.example.client4;

import com.example.client4.config.AppConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class TestConfig {

    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(TestConfig.class, args);
        AppConfig config = context.getBean(AppConfig.class);
        
        // Test that we can access the obfuscated methods
        System.out.println("Name: " + config.getCfg_b068931c());
        System.out.println("Version: " + config.getCfg_2af72f10());
        System.out.println("Description: " + config.getCfg_67daf92c());
    }
}