package com.example.client4.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "configurations.cfg_d2a57dc1")
public class AppConfig {
    private String cfg_b068931c;
    private String cfg_2af72f10;
    private String cfg_67daf92c;

    // Getters and setters
    public String getCfg_b068931c() {
        return cfg_b068931c;
    }

    public void setCfg_b068931c(String cfg_b068931c) {
        this.cfg_b068931c = cfg_b068931c;
    }

    public String getCfg_2af72f10() {
        return cfg_2af72f10;
    }

    public void setCfg_2af72f10(String cfg_2af72f10) {
        this.cfg_2af72f10 = cfg_2af72f10;
    }

    public String getCfg_67daf92c() {
        return cfg_67daf92c;
    }

    public void setCfg_67daf92c(String cfg_67daf92c) {
        this.cfg_67daf92c = cfg_67daf92c;
    }

    @Override
    public String toString() {
        return "AppConfig{" +
                "name='" + cfg_b068931c + '\'' +
                ", version='" + cfg_2af72f10 + '\'' +
                ", description='" + cfg_67daf92c + '\'' +
                '}';
    }
}