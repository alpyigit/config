package com.example.client1.controller;

import com.example.client1.config.AppConfig;
import com.example.client1.config.DatabaseConfig;
import com.example.client1.config.FeatureConfig;
import com.example.client1.config.ExternalServicesConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ConfigController {

    @Autowired
    private AppConfig appConfig;

    @Autowired
    private DatabaseConfig databaseConfig;

    @Autowired
    private FeatureConfig featureConfig;

    @Autowired
    private ExternalServicesConfig externalServicesConfig;

    @GetMapping("/config")
    public Map<String, Object> getConfig() {
        return Map.of(
            "appName", appConfig.getCfg_a066aa4a(),
            "appVersion", appConfig.getCfg_9d4ee38e(),
            "appDescription", appConfig.getCfg_8b9aa0a2(),
            "databaseUrl", databaseConfig.getCfg_04c13529(),
            "cachingEnabled", featureConfig.isCfg_91256073(),
            "paymentService", externalServicesConfig.getCfg_4eb47435()
        );
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "UP", "app", appConfig.getCfg_a066aa4a());
    }
    
    // Method using original (unobfuscated) configuration names for testing refactoring
    @GetMapping("/test-refactor")
    public Map<String, String> testRefactor() {
        return Map.of(
            "name", appConfig.getCfg_b068931c(),
            "version", appConfig.getCfg_2af72f10(),
            "description", appConfig.getCfg_67daf92c()
        );
    }
    
    // Method using intermediate obfuscated name for testing refactoring
    @GetMapping("/test-refactor2")
    public Map<String, String> testRefactor2() {
        return Map.of(
            "testName", appConfig.getCfg_a066aa4a()
        );
    }
    
    // Method to test both getter and setter refactoring
    @GetMapping("/test-getter-setter")
    public Map<String, String> testGetterSetter() {
        // These will be refactored to use the correct obfuscated methods
        appConfig.setCfg_a066aa4a("Test Name");
        String name = appConfig.getCfg_a066aa4a();
        return Map.of("name", name);
    }
}