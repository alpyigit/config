package com.example.client1.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "configurations.external.services")
public class ExternalServicesConfig {
    private String cfg_4eb47435;
    private String cfg_52f8d3a8;

    public String getCfg_4eb47435() {
        return cfg_4eb47435;
    }

    public void setCfg_4eb47435(String cfg_4eb47435) {
        this.cfg_4eb47435 = cfg_4eb47435;
    }

    public String getCfg_52f8d3a8() {
        return cfg_52f8d3a8;
    }

    public void setCfg_52f8d3a8(String cfg_52f8d3a8) {
        this.cfg_52f8d3a8 = cfg_52f8d3a8;
    }
}