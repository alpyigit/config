package com.example.client1.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "configurations.feature.flags")
public class FeatureConfig {
    private boolean cfg_91256073;
    private boolean cfg_0a0b7315;
    private boolean cfg_23b26ae7;

    public boolean isCfg_91256073() {
        return cfg_91256073;
    }

    public void setCfg_91256073(boolean cfg_91256073) {
        this.cfg_91256073 = cfg_91256073;
    }

    public boolean isCfg_0a0b7315() {
        return cfg_0a0b7315;
    }

    public void setCfg_0a0b7315(boolean cfg_0a0b7315) {
        this.cfg_0a0b7315 = cfg_0a0b7315;
    }

    public boolean isCfg_23b26ae7() {
        return cfg_23b26ae7;
    }

    public void setCfg_23b26ae7(boolean cfg_23b26ae7) {
        this.cfg_23b26ae7 = cfg_23b26ae7;
    }
}