package com.example.client1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientApp1Application {

    public static void main(String[] args) {
        SpringApplication.run(ClientApp1Application.class, args);
    }
}