# Profile-Specific Configuration Guide

This document explains how to use the profile-specific configurations that have been implemented for the client applications.

## Configuration Structure

Each client application now has profile-specific configurations in their runtime YAML files:

1. **Default/Development Configuration**: The first section of each YAML file contains the development configuration
2. **Production Configuration**: The second section (after `---`) contains the production configuration, activated with `spring.profiles: prod`

## How to Activate Profiles

### For Client Applications

To activate a specific profile for a client application, you need to set the `spring.profiles.active` property.

#### Method 1: Environment Variable
```bash
export SPRING_PROFILES_ACTIVE=prod
```

#### Method 2: Application Property
Add to the client application's `application.yml`:
```yaml
spring:
  profiles:
    active: prod
```

#### Method 3: Command Line
When starting the application:
```bash
mvn spring-boot:run -Dspring.profiles.active=prod
```

## Profile Differences

### Client App 1
- **Development Version**: "1.0.0-DEV"
- **Production Version**: "1.0.0"
- **Other Differences**: 
  - Database: In-memory H2 (dev) vs File-based H2 (prod)
  - Logging levels: More verbose in dev, less in prod
  - Security: Disabled in dev, enabled in prod
  - Rate limits: Higher in dev, lower in prod
  - External services: Local URLs in dev, production URLs in prod

### Client App 2
- **Development Version**: "2.0.0-DEV"
- **Production Version**: "2.0.0"
- **Other Differences**:
  - Database: Local PostgreSQL (dev) vs Production PostgreSQL (prod)
  - Logging levels: DEBUG/INFO in dev, WARN/INFO in prod
  - Caching: Disabled in dev, enabled in prod
  - Rate limits: Higher in dev, lower in prod
  - Security: Different JWT secrets and expiration times
  - External services: Local URLs in dev, production URLs in prod
  - Redis: Local in dev, production server in prod

### Client App 3
- **Development Version**: "3.0.0-DEV"
- **Production Version**: "3.0.0"
- **Other Differences**:
  - Database: Local MySQL (dev) vs Production MySQL (prod)
  - Logging levels: More verbose in dev, less in prod
  - Rate limits: Higher in dev, lower in prod
  - Security: Different OAuth2 credentials
  - External services: Local URLs in dev, production URLs in prod
  - Redis: Local in dev, production server in prod
  - Batch processing: Higher chunk size and thread pool in dev, lower in prod

## Testing Profile-Specific Configurations

### Via Config Server API
You can directly test what configurations are served by the Config Server:

1. **Development Profile**:
   ```bash
   curl http://localhost:8889/client-app-1/dev
   ```

2. **Production Profile**:
   ```bash
   curl http://localhost:8889/client-app-1/prod
   ```

### Via Client Applications
Start client applications with different profiles and check their `/config` endpoints:

1. **Development Profile** (default):
   ```bash
   cd client-app-1
   mvn spring-boot:run
   curl http://localhost:8081/config
   ```

2. **Production Profile**:
   ```bash
   cd client-app-1
   mvn spring-boot:run -Dspring.profiles.active=prod
   curl http://localhost:8081/config
   ```

## Verification

When you check the `/config` endpoint of each client application, you should see:
- The version field will show "X.X.X-DEV" for development profile
- The version field will show "X.X.X" for production profile
- Other configuration values will reflect the profile-specific settings as described above

This profile-based configuration system allows you to have different settings for development and production environments while maintaining a single configuration file per application.