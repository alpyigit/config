package com.example.configencryptor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigEncryptorApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConfigEncryptorApplication.class, args);
    }
}