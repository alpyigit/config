package com.example.configencryptor.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;

@Service
public class EncryptionService {
    
    private static final String CIPHER_PREFIX = "{cipher}";
    
    @Value("${config.server.url:http://localhost:8889}")
    private String configServerUrl;
    
    private final RestTemplate restTemplate;
    
    @Autowired
    public EncryptionService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
    
    public String encrypt(String plainText) {
        if (plainText == null || plainText.trim().isEmpty()) {
            return plainText;
        }
        
        // Don't encrypt already encrypted values
        if (plainText.startsWith(CIPHER_PREFIX)) {
            return plainText;
        }
        
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.TEXT_PLAIN);
            
            HttpEntity<String> request = new HttpEntity<>(plainText, headers);
            
            ResponseEntity<String> response = restTemplate.exchange(
                configServerUrl + "/encrypt",
                HttpMethod.POST,
                request,
                String.class
            );
            
            String encryptedValue = response.getBody();
            return CIPHER_PREFIX + encryptedValue;
            
        } catch (HttpClientErrorException | ResourceAccessException e) {
            throw new RuntimeException("Failed to encrypt value via Config Server: " + e.getMessage(), e);
        }
    }
    
    public String decrypt(String encryptedText) {
        if (encryptedText == null || !encryptedText.startsWith(CIPHER_PREFIX)) {
            return encryptedText;
        }
        
        try {
            // Remove the {cipher} prefix
            String cipherValue = encryptedText.substring(CIPHER_PREFIX.length());
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.TEXT_PLAIN);
            
            HttpEntity<String> request = new HttpEntity<>(cipherValue, headers);
            
            ResponseEntity<String> response = restTemplate.exchange(
                configServerUrl + "/decrypt",
                HttpMethod.POST,
                request,
                String.class
            );
            
            return response.getBody();
            
        } catch (HttpClientErrorException | ResourceAccessException e) {
            throw new RuntimeException("Failed to decrypt value via Config Server: " + e.getMessage(), e);
        }
    }
    
    public boolean isEncrypted(String value) {
        return value != null && value.startsWith(CIPHER_PREFIX);
    }
    
    /**
     * Test if the Config Server is available
     */
    public boolean isConfigServerAvailable() {
        try {
            String healthUrl = configServerUrl + "/actuator/health";
            ResponseEntity<String> response = restTemplate.getForEntity(healthUrl, String.class);
            return response.getStatusCode() == HttpStatus.OK;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Get the Config Server URL being used
     */
    public String getConfigServerUrl() {
        return configServerUrl;
    }
}